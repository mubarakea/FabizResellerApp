package com.officialakbarali.fabiz.data;

public class MyAppVersion {
    private static int APP_VERSION = 1;

    public static int GET_MY_APP_VERSION() {
        return APP_VERSION;
    }
}
